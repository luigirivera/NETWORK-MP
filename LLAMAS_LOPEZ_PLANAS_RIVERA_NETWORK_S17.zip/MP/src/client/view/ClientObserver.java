package client.view;

public interface ClientObserver {
	public void update();
}

package message;

public interface ChatMessage {
}

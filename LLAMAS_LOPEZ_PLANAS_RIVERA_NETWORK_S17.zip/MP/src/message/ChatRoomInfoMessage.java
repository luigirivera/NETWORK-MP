package message;

import message.content.ChatRoomInfo;

public class ChatRoomInfoMessage extends Message<ChatRoomInfo> {
	private static final long serialVersionUID = 1L;
}

package message;

import message.content.FileRequest;

public class FileRequestMessage extends Message<FileRequest> {
	private static final long serialVersionUID = 1L;
}
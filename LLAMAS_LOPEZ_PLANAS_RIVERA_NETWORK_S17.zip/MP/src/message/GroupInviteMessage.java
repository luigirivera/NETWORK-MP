package message;

import message.content.GroupInvite;

public class GroupInviteMessage extends Message<GroupInvite> {
	private static final long serialVersionUID = 1L;
}

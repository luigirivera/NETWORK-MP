package message;

import message.content.GroupLeave;

public class GroupLeaveMessage extends Message<GroupLeave> {
	private static final long serialVersionUID = 1L;
}

package message;

import message.content.PublicGroupCreate;

public class PublicGroupCreateMessage extends Message<PublicGroupCreate> {
	private static final long serialVersionUID = 1L;
}

package message.content;

public enum LoginResult {
	SUCCESS, FAILED;
}

package message.content;

import java.util.ArrayList;

public class UsernameList extends ArrayList<String> {
	private static final long serialVersionUID = 1L;
}

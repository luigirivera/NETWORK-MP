package message.utility;

public enum MessageScope {
	GLOBAL, DIRECT, GROUP, ROOM;
}

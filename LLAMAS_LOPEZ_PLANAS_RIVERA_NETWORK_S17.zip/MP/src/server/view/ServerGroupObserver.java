package server.view;

public interface ServerGroupObserver {
	public void updateGroups();
}

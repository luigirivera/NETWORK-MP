package server.view;

public interface ServerMessageObserver {
	public void updateMessages();
}

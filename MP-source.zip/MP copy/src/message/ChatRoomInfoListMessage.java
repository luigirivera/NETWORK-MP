package message;

import message.content.ChatRoomInfoList;

public class ChatRoomInfoListMessage extends Message<ChatRoomInfoList> {
	private static final long serialVersionUID = 1L;
}

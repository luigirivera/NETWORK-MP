package message;

import message.content.FileContent;

public class FileMessage extends Message<FileContent> implements ChatMessage {
	private static final long serialVersionUID = 1L;
}

package message;

import message.content.GroupJoin;

public class GroupJoinMessage extends Message<GroupJoin> {
	private static final long serialVersionUID = 1L;	
}

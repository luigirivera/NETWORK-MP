package message;

import message.content.LoginAttempt;

public class LoginAttemptMessage extends Message<LoginAttempt> {
	private static final long serialVersionUID = 1L;
}
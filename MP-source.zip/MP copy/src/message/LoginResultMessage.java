package message;

import message.content.LoginResult;

public class LoginResultMessage extends Message<LoginResult> {
	private static final long serialVersionUID = 1L;
}
package message;

import message.content.PrivateGroupCreate;

public class PrivateGroupCreateMessage extends Message<PrivateGroupCreate> {
	private static final long serialVersionUID = 1L;
}

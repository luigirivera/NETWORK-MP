package message;

public class TextMessage extends Message<String> implements ChatMessage {
	private static final long serialVersionUID = 1L;
}
package message;

import message.content.UsernameList;

public class UsernameListMessage extends Message<UsernameList> {
	private static final long serialVersionUID = 1L;
}
package message.content;

import java.util.ArrayList;

public class ChatRoomInfoList extends ArrayList<ChatRoomInfo> {
	private static final long serialVersionUID = 1L;
}

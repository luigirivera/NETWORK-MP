package server.view;

public interface ServerLogObserver {
	public void updateLog();
}

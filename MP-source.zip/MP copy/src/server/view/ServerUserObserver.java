package server.view;

public interface ServerUserObserver {
	public void updateUsers();
}

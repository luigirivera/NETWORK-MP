package server;

public interface ServerObserver {
	public void update(String message);
}

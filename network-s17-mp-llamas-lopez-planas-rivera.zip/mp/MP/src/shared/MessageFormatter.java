package shared;

public interface MessageFormatter {
	public String format(Message message);
}

package shared;

public interface MessageRouter {
	public void route(Message message);
}
